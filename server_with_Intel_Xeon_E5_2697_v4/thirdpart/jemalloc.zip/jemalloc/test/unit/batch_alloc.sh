#!/bin/sh

export MALLOC_CONF="tcache_gc_incr_bytes:2147483648"
