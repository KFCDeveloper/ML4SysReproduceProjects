#! /bin/bash -xe

docker build -t appqos -f Dockerfile ../../
